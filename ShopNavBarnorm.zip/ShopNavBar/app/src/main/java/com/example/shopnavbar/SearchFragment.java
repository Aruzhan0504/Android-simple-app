package com.example.shopnavbar;

import android.app.AlertDialog;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;


public class SearchFragment extends Fragment {
     /*
    TextView name,age;
    Button collect;

    AlertDialog dialog;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_search, container, false);

        name = findViewById(R.id.name_view);
        age = findViewById(R.id.age_view);
       collect  = findViewById(R.id.collect);

       AlertDialog.Builder builder = new AlertDialog.Builder(this);
       builder.setTitle("Enter Data");

       View view = getLayoutInflater().inflate(R.layout.custom_dialog,null);
        EditText eName,eAge;
        eName = view.findViewById(R.id.name);
         eAge = view.findViewById(R.id.age);
         Button submit = view.findViewById(R.id.submit);
         submit.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View v) {
                 name.setText("Name: " + eName.getText().toString());
                 age.setText("Name: " + eAge.getText().toString());
                 dialog.dismiss();
             }
         });

         builder.setView(view);
         dialog = builder.create();

         collect.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View v) {
                 dialog.show();
             }
         });

    }    */ 
}