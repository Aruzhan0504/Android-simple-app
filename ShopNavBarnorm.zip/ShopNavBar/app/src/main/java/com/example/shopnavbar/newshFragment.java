package com.example.shopnavbar;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class newshFragment extends Fragment {
/*
    private View view;
    // Инициализация RecyclerView
    RecyclerView recyclerView = view.findViewById(R.id.recycler_view); // Убедитесь, что `recycler_view` правильный

    private ProductAdapter productAdapter;
    private List<Product> productList;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Загружаем макет для фрагмента
        View view = inflater.inflate(R.layout.fragment_search, container, false);

        // Инициализируем RecyclerView
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        // Создаем список продуктов
        productList = new ArrayList<>();
        productList.add(new Product("Product 1", 19.99, "This is product 1 description"));
        productList.add(new Product("Product 2", 29.99, "This is product 2 description"));
        productList.add(new Product("Product 3", 39.99, "This is product 3 description"));

        // Устанавливаем адаптер
        productAdapter = new ProductAdapter(productList);
        recyclerView.setAdapter(productAdapter);

        return view;
    }*/
}
